<li class="nav-item">
    <a class="nav-link" href="create_va.php">Create a Visiting Academic</a>
</li>
<li class="nav-item">
    <a class="nav-link" href="create_visit.php">Create a Visit</a>
</li>
<li class="nav-item">
    <a class="nav-link" href="view_requests.php">View My Pending Requests</a>
</li>
<li class="nav-item">
    <a class="nav-link" href="view_complete.php">View My Complete Requests</a>
</li>