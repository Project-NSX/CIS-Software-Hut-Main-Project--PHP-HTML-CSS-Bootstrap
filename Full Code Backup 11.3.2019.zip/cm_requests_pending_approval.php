<?php require 'includes/header.php';?>
<!--HTML HERE-->
<h2>College Manager - Requests Pending Approval</h2>
<?php require'includes/navbars/nav_picker.php';?>
<!--This page should show all requests pending approval by the CM-->



<?php require 'includes/footer.php';?>