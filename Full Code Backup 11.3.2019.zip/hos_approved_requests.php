<?php require 'includes/header.php';?>
<!--HTML HERE-->
<h2>Head of School - Approved Requests</h2>
<?php require'includes/navbars/nav_picker.php';?>
<!-- This page should show all requests approved by the HOS-->

<?php require 'includes/footer.php';?>