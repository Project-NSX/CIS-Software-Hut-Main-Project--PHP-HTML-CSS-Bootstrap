<?php require 'includes/header.php';?>
<!--HTML HERE-->
<h2>Human Resources - Application Details</h2>
<?php require'includes/navbars/nav_picker.php';?>
<!--This page should show the full details of an application when it's clicked on
in the tables from various pages-->

<?php require 'includes/footer.php';?>