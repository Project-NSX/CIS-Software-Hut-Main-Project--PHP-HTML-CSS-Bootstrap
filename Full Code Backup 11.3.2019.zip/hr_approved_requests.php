<?php require 'includes/header.php';?>
<!--HTML HERE-->
<h2>Human Resources - Approved Requests</h2>
<?php require'includes/navbars/nav_picker.php';?>
<!--This page needs to show requests that have been approved (by who? HR? both HOS and HR?)-->


<?php require 'includes/footer.php';?>