<?php require 'includes/header.php';?>
<!--HTML HERE-->
<h2>Head of School - Landing</h2>
<?php require'includes/navbars/nav_picker.php';?>



<?php require 'includes/footer.php';?>