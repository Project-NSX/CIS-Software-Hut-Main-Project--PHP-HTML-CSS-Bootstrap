<?php require 'includes/header.php';?>
<!--HTML HERE-->
<h2>Human Resources - Applications Pending Approval</h2>
<?php require'includes/navbars/nav_picker.php';?>
<!--This page needs to show application pending approval from HR-->

<?php require 'includes/footer.php';?>