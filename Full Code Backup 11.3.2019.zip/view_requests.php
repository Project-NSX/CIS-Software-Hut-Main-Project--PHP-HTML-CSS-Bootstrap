<?php require 'includes/header.php';?>
<!--HTML HERE-->
<h2>Pending Requests</h2>
<?php require'includes/navbars/nav_picker.php';?>
<!--
    TODO: https://www.w3schools.com/php/php_mysql_select.asp
    https://www.siteground.com/tutorials/php-mysql/display-table-data/
    Make this page display a table of incomplete requests (hos / hr approved : false?)

    TODO: when clicked on the table should show full details of the VA and the visit

-->


<?php require 'includes/footer.php';?>