<?php require 'includes/header.php';?>
<!--HTML HERE-->
<h2>Head of School - Pending Requests</h2>
<?php require'includes/navbars/nav_picker.php';?>
<!--This page should show all requests pending approval by a HOS-->



<?php require 'includes/footer.php';?>