<?php require 'includes/header.php';?>
<!--HTML HERE-->
<h2>Visiting Academic Application Details</h2>
<?php require'includes/navbars/nav_picker.php';?>



<?php require 'includes/footer.php';?>